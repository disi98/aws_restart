print("Hello world")
# integrs

int1 = 10
int2 = 20

print(int1 + int2)